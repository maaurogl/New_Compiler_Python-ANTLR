from vpython import *
from math import *

class Turtle3D:
    __pos = vector(0, 0, 0)
    __alpha = 0
    __beta = 0
    __hidden = False
    __color = color.white

    def __init__(self):
        self.__pos = vector(0, 0, 0)
        self.__alpha = 0
        self.__beta = 0
        self.__hidden = False
        self.__color = color.white

    def home(self):
        self.__pos = vector(0, 0, 0)

    def forward(self, dist):
        displacement = calcDir(self.__alpha, self.__beta) * dist
        if not self.__hidden:
            cylinder(pos=self.__pos, axis=displacement, radius=0.1, color=self.__color)
        self.__pos += displacement
        bola = sphere(pos=self.__pos, radius=0.1, color=self.__color)

    def backward(self, dist):
        displacement = calcDir(self.__alpha, self.__beta) * -dist
        if not self.__hidden:
            cylinder(pos=self.__pos, axis=displacement, radius=0.1, color=self.__color)
        self.__pos += displacement
        bola = sphere(pos=self.__pos, radius=0.1, color=self.__color)

    def hide(self):
        self.__hidden = True

    def show(self):
        self.__hidden = False

    def right(self, rotation):
        self.__alpha += rotation

    def left(self, rotation):
        self.__alpha -= rotation

    def up(self, rotation):
        self.__beta += rotation

    def down(self, rotation):
        self.__beta -= rotation

    def color(self, colorX, colorY, colorZ):
        self.__color = color.hsv_to_rgb(vector (colorX, colorY, colorZ))

def calcDir(alpha, beta):
    x = cos(radians(alpha)) * cos(radians(beta))
    z = sin(radians(alpha)) * cos(radians(beta))
    y = sin(radians(beta))
    return vector(x,y,z)
