# Generated from logo3d.g by ANTLR 4.7.2
from antlr4 import *
from vpython import *
if __name__ is not None and "." in __name__:
    from .logo3dParser import logo3dParser
    from .logo3dVisitor import logo3dVisitor
    from .turtle3d import Turtle3D
else:
    from logo3dParser import logo3dParser
    from logo3dVisitor import logo3dVisitor
    from turtle3d import Turtle3D

# This class defines a complete generic visitor for a parse tree produced by ExprParser.

class logo3dVisitorChild(logo3dVisitor):
    __functions = {}
    __functionParams = {}
    __variables = {}
    __initialFunc = "main"
    __initialParams = []
    __turtle = Turtle3D()

    # Constructora
    def __init__(self, argv_list):

        size = len(argv_list)

        if size > 0:
            self.__initialFunc = argv_list[0]

        if size > 1:
            for i in argv_list[1:]:
                if float(i):
                    self.__initialParams.append(float(i))
                elif int(i):
                    self.__initialParams.append(int(i))
                else:
                    self.__initialParams.append(i)

        # paràmetres de l'escena
        scene.height = scene.width = 1000
        scene.autocenter = True
        scene.caption = """\nTo rotate "camera", drag with right button or Ctrl-drag.\nTo zoom, drag with middle button or Alt/Option depressed, or use scroll wheel.\n  On a two-button mouse, middle is left + right.\nTo pan left/right and up/down, Shift-drag.\nTouch screen: pinch/extend to zoom, swipe or two-finger rotate.\n"""

        # posa els eixos de coordenades blancs
        cylinder(pos=vector(0, 0, 0), axis=vector(10, 0, 0), radius=0.1, color=color.white)
        cylinder(pos=vector(0, 0, 0), axis=vector(0, 10, 0), radius=0.1, color=color.red)
        cylinder(pos=vector(0, 0, 0), axis=vector(0, 0, 10), radius=0.1, color=color.blue)

    # Visit a parse tree produced by ExprParser#root.
    def visitRoot(self, ctx):
        child = list(ctx.getChildren())
        self.visit(child[0])

        if len(child) > 2:
            for i in range(len(self.__functionParams[self.__initialFunc])):
                paramName = self.__functionParams[self.__initialFunc][i]
                self.__variables[paramName] = self.__initialParams[i]
            self.visit(self.__functions[self.__initialFunc])
            for i in range(len(self.__functionParams[self.__initialFunc])):
                paramName = self.__functionParams[self.__initialFunc][i]
                del self.__variables[paramName]
        else:
            self.visit(self.__functions[self.__initialFunc])


    # Visit a parse tree produced by logo3dParser#bloque.
    def visitBloque(self, ctx):
        return self.visitChildren(ctx)

    # Visit a parse tree produced by ExprParser#proc.
    def visitProc(self, ctx):
        child = list(ctx.getChildren())
        funcName = self.visit(child[1])
        self.__functions[funcName] = child[3]

    # Visit a parse tree produced by ExprParser#instr.
    def visitInstr(self, ctx):
        child = list(ctx.getChildren())
        return self.visitChildren(ctx)


    # Visit a parse tree produced by ExprParser#expr.
    def visitExpr(self, ctx):
        child = list(ctx.getChildren())
        if len(child) == 1:
            if logo3dParser.symbolicNames[child[0].getSymbol().type] == "VAR":
                if child[0].getText() in self.__variables:
                    return self.__variables[child[0].getText()]
                else:
                    print("ERROR: La variable '" + child[0].getText() + "' no s'ha declarat")
            else:
                if float(child[0].getText()):
                    return float(child[0].getText())
                else:
                    return int(child[0].getText())

        else:
            # len(Child) == 3
            leftExpr = self.visit(child[0])
            rightExpr = self.visit(child[2])
            op = child[1].getText()

            if op == '+' :
                return leftExpr + rightExpr

            if op == '-' :
                return leftExpr - rightExpr

            if op == '*' :
                return leftExpr * rightExpr

            if op == '/' :
                return leftExpr / rightExpr


    # Visit a parse tree produced by ExprParser#compar.
    def visitCompar(self, ctx):
        child = list(ctx.getChildren())
        if len(child) == 1:
            return self.visit(child[0])
        else :
            # len(Child) == 3
            leftExpr = self.visit(child[0])
            rightExpr = self.visit(child[2])
            op = child[1].getText()

            if op == '==' :
                return leftExpr == rightExpr

            if op == '!=' :
                return leftExpr != rightExpr

            if op == '<=' :
                return leftExpr <= rightExpr
                
            if op == '>=' :
                return leftExpr >= rightExpr

            if op == '>' :
                return leftExpr > rightExpr

            if op == '<' :
                return leftExpr < rightExpr

    # Visit a parse tree produced by ExprParser#assig.
    def visitAssig(self, ctx):
        child = list(ctx.getChildren())
        varName = child[0].getText()
        self.__variables[varName] = self.visit(child[2])


    # Visit a parse tree produced by ExprParser#lectr.
    def visitLectr(self, ctx):
        child = list(ctx.getChildren())
        varName = child[1].getText()
        self.__variables[varName] = float(input())


    # Visit a parse tree produced by ExprParser#escript.
    def visitEscript(self, ctx):
        child = list(ctx.getChildren())
        print(self.visit(child[1]))


    # Visit a parse tree produced by ExprParser#condi.
    def visitCondi(self, ctx):
        child = list(ctx.getChildren())
        if self.visit(child[1]):
            self.visit(child[3])
        elif len(child) == 7:
            self.visit(child[5])


    # Visit a parse tree produced by ExprParser#whileloop.
    def visitWhileloop(self, ctx):
        child = list(ctx.getChildren())
        while self.visit(child[1]):
            self.visit(child[3])


    # Visit a parse tree produced by ExprParser#forloop.
    def visitForloop(self, ctx):
        child = list(ctx.getChildren())
        i = child[1].getText()
        a = self.visit(child[3])
        b = self.visit(child[5])
        self.__variables[i] = a
        while self.__variables[i] <= b:
            self.visit(child[7])
            self.__variables[i] += 1

    # Visit a parse tree produced by logo3dParser#executefunc.
    def visitExecutefunc(self, ctx):
        child = list(ctx.getChildren())
        funcName = child[0].getText()
        if len(child) > 2:
            paramsValues = self.visit(child[2])
            if not self.turtleFunction(funcName, paramsValues):
                aux = self.__functionParams[funcName]
                for i in range(len(self.__functionParams[funcName])):
                    paramName = self.__functionParams[funcName][i]
                    self.__variables[paramName] = paramsValues[i]
                self.visit(self.__functions[funcName])
                for i in range(len(self.__functionParams[funcName])):
                    paramName = self.__functionParams[funcName][i]
                self.__functionParams[funcName] = aux

        else:
            if not self.turtleFunction(funcName, []):
                self.visit(self.__functions[funcName])

    # Visit a parse tree produced by logo3dParser#paramsFunc.
    def visitParamsFunc(self, ctx):
        child = list(ctx.getChildren())
        if len(child) == 1:
            return [self.visit(child[0])]
        else:
            return [self.visit(child[0])] + self.visit(child[2])

    # Visit a parse tree produced by logo3dParser#func.
    def visitFunc(self, ctx):
        child = list(ctx.getChildren())
        funcName = child[0].getText()
        self.__functionParams[funcName] = []
        if len(child) > 2:
            params = self.visit(child[2])
            self.__functionParams[funcName] = params
        return funcName

    # Visit a parse tree produced by logo3dParser#params.
    def visitParams(self, ctx):
        child = list(ctx.getChildren())
        if len(child) == 1:
            return [child[0].getText()]
        else:
            return [child[0].getText()] + self.visit(child[2])

    def turtleFunction(self, name, params):
        if name == "home":
            self.__turtle.home()
            return True
        elif name == "forward":
            self.__turtle.forward(params[0])
            return True
        elif name == "backward":
            self.__turtle.backward(params[0])
            return True
        elif name == "hide":
            self.__turtle.hide()
            return True
        elif name == "show":
            self.__turtle.show()
            return True
        elif name == "right":
            self.__turtle.right(params[0])
            return True
        elif name == "left":
            self.__turtle.left(params[0])
            return True
        elif name == "up":
            self.__turtle.up(params[0])
            return True
        elif name == "down":
            self.__turtle.down(params[0])
            return True
        elif name == "color":
            self.__turtle.color(params[0], params[1], params[2])
            return True
        return False